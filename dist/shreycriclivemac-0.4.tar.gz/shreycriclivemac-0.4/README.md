Run the following command inside your mac terminal:

```
pip install shreycricmac
shreycricmac run
```
